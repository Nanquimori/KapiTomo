(function () {
  try {
    var origin = location.origin || "";
    var path = location.pathname || "";
    var hash = location.hash || "";
    var cleanPath = path.replace(/\/index\.html$/i, "").replace(/\/+$/g, "");
    var basePath = "/KapiTomo";
    var baseMatch = cleanPath.match(/^(.*?)(?:\/manga\/|\/chapter\/|$)/i);
    if (baseMatch && baseMatch[1]) {
      basePath = baseMatch[1].replace(/\/+$/g, "") || "/KapiTomo";
    }
    var base = origin + basePath;
    var match = cleanPath.match(/\/manga\/([^\/?#]+)/i);
    if (match) {
      return base + "/manga/" + match[1] + "/";
    }
    var hashWork = hash.match(/^#\/?obra\/([^\/?#]+)/i);
    if (hashWork) {
      return base + "/manga/" + hashWork[1] + "/";
    }
    var hashChapter = hash.match(/^#\/?ler\/([^\/?#]+)\/([0-9]+)/i);
    if (hashChapter) {
      return base + "/manga/" + hashChapter[1] + "/" + hashChapter[2] + "/";
    }
    var anchor = document.querySelector('a[href*="/manga/"], a[href^="#obra/"]');
    if (anchor && anchor.href) {
      return anchor.href.replace("/KapiTomo/#obra/", "/KapiTomo/manga/") + (anchor.href.indexOf("#obra/") >= 0 ? "/" : "");
    }
    var canonical = document.querySelector('link[rel="canonical"]');
    if (canonical && canonical.href && canonical.href.indexOf("/manga/") >= 0) {
      return canonical.href;
    }
    return "";
  } catch (error) {
    return "";
  }
})()
