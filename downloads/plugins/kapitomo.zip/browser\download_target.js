(function () {
  try {
    var routes = {
      basePath: "KapiTomo",
      series: "manga",
      workHash: "obra",
      readHash: "ler",
      chapter: "chapter"
    };

    function clean(value) {
      return String(value || "").replace(/\s+/g, " ").trim();
    }

    function firstNumber(value, fallback) {
      var match = clean(value).match(/(\d+(?:[.,]\d+)?)/);
      return match ? match[1].replace(",", ".") : String(fallback);
    }

    function basePath() {
      var path = String(location.pathname || "").replace(/\/index\.html$/i, "").replace(/\/+$/g, "");
      var marker = "/" + routes.series + "/";
      var markerIndex = path.toLowerCase().indexOf(marker.toLowerCase());
      if (markerIndex >= 0) {
        return path.slice(0, markerIndex).replace(/^\/+|\/+$/g, "") || routes.basePath;
      }
      var firstPart = path.split("/").filter(Boolean)[0];
      return firstPart || routes.basePath;
    }

    function baseUrl() {
      var prefix = basePath();
      return String(location.origin || "").replace(/\/+$/g, "") + (prefix ? "/" + prefix : "");
    }

    function absolute(value) {
      var raw = clean(value);
      if (!raw) return "";
      try {
        return new URL(raw, baseUrl() + "/").href;
      } catch (error) {
        return raw;
      }
    }

    function workUrl(slug) {
      return baseUrl() + "/" + routes.series + "/" + encodeURIComponent(slug) + "/";
    }

    function chapterUrl(slug, index) {
      return workUrl(slug) + routes.chapter + "/" + encodeURIComponent(String(index)) + "/";
    }

    function slugFromUrl() {
      var path = String(location.pathname || "").replace(/\/index\.html$/i, "").replace(/\/+$/g, "");
      var pathMatch = path.match(new RegExp("\\/" + routes.series + "\\/([^\\/?#]+)", "i"));
      if (pathMatch) return decodeURIComponent(pathMatch[1]);

      var hash = String(location.hash || "").replace(/^#\/?/, "");
      var workPattern = new RegExp("^" + routes.workHash + "\\/([^\\/?#]+)", "i");
      var readPattern = new RegExp("^" + routes.readHash + "\\/([^\\/?#]+)(?:\\/([^\\/?#]+))?", "i");
      var workMatch = hash.match(workPattern);
      if (workMatch) return decodeURIComponent(workMatch[1]);
      var readMatch = hash.match(readPattern);
      if (readMatch) return decodeURIComponent(readMatch[1]);

      var anchor = document.querySelector("a[href^='#" + routes.workHash + "/'], a[href^='#" + routes.readHash + "/']");
      if (anchor) {
        var href = String(anchor.getAttribute("href") || "").replace(/^#\/?/, "");
        var anchorMatch = href.match(workPattern) || href.match(readPattern);
        if (anchorMatch) return decodeURIComponent(anchorMatch[1]);
      }
      return "";
    }

    function findWork(slug) {
      var works = Array.isArray(window.KAPI_TOMO_WORKS) ? window.KAPI_TOMO_WORKS : [];
      for (var index = 0; index < works.length; index++) {
        if (clean(works[index] && works[index].id) === slug) return works[index];
      }
      return null;
    }

    function chapterPlan(work) {
      var slug = clean(work && work.id);
      if (!slug) return "";
      var canonicalUrl = workUrl(slug);
      var chapters = Array.isArray(work.chapters) ? work.chapters : [];
      if (!chapters.length) return "";

      var plan = {
        title: clean(work.title) || slug,
        summary: clean(work.description || work.summary),
        canonicalUrl: canonicalUrl,
        coverUrl: absolute(work.cover),
        chapters: chapters.map(function (chapter, index) {
          var title = clean(chapter && chapter.title) || ("Capitulo " + (index + 1));
          var number = firstNumber(title, index + 1);
          return {
            id: "id:" + index,
            number: number,
            title: title,
            label: "Cap " + number + " - " + title,
            url: chapterUrl(slug, index),
            index: index
          };
        })
      };

      window.__nyxoviraChapterPlan = JSON.stringify(plan);
      return canonicalUrl;
    }

    var slug = slugFromUrl();
    if (slug) {
      var work = findWork(slug);
      if (work) return chapterPlan(work);
      return workUrl(slug);
    }

    var canonical = document.querySelector("link[rel='canonical']");
    if (canonical && canonical.href && canonical.href.indexOf("/" + routes.series + "/") >= 0) {
      return canonical.href;
    }
    return "";
  } catch (error) {
    return "";
  }
})()
