(function () {
  try {
    var origin = location.origin || "";
    var path = location.pathname || "";
    var hash = location.hash || "";
    var base = origin + "/KapiTomo";
    var match = path.match(/^\/KapiTomo\/manga\/([^\/?#]+)/i);
    if (match) {
      return base + "/manga/" + match[1] + "/";
    }
    var hashWork = hash.match(/^#obra\/([^\/?#]+)/i);
    if (hashWork) {
      return base + "/manga/" + hashWork[1] + "/";
    }
    var hashChapter = hash.match(/^#ler\/([^\/?#]+)\/([0-9]+)/i);
    if (hashChapter) {
      return base + "/manga/" + hashChapter[1] + "/" + hashChapter[1] + "-chapter-" + hashChapter[2] + "/";
    }
    var canonical = document.querySelector('link[rel="canonical"]');
    if (canonical && canonical.href && canonical.href.indexOf("/KapiTomo/") >= 0) {
      return canonical.href;
    }
    var anchor = document.querySelector('a[href*="/manga/"], a[href^="#obra/"]');
    if (anchor && anchor.href) {
      return anchor.href.replace("/KapiTomo/#obra/", "/KapiTomo/manga/") + (anchor.href.indexOf("#obra/") >= 0 ? "/" : "");
    }
    return base + "/";
  } catch (error) {
    return "";
  }
})()
